import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';

/*
  Generated class for the DataProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class DataProvider {

    futuramaEpisodes: any = [
        {
            season: "Season One",
            episodes: [
                {
                    episodeTitle: "Space Pilot 3000",
                    airDate: "March 28,1999"
                }, {
                    episodeTitle: "The Series Has Landed",
                    airDate: "April 4,1999"
                }, {
                    episodeTitle: "I, Roommate",
                    airDate: "April 6,1999"
                }]
        }, {
            season: "Season Two",
            episodes: [
                {
                    episodeTitle: "I Second That Emotion",
                    airDate: "November 21, 1999"
                }, {
                    episodeTitle: "Brannigan, Begin Again",
                    airDate: "November 28, 1999"
                }, {
                    episodeTitle: "A Head in the Polls",
                    airDate: "December 12, 1999"
                }]
        }]

    constructor() {
        console.log('Hello DataProvider Provider');
    }

}

import { Component } from '@angular/core';
import {IonicPage, NavController} from 'ionic-angular';
import {DataProvider} from "../../providers/data/data";

@IonicPage()

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  mainLists:any;

  constructor(public navCtrl: NavController, public data: DataProvider) {

  }

  ionViewDidLoad(){
    this.mainLists = this.data.futuramaEpisodes;
  }

  episodeClicked(clickedEpisode):void{
    this.navCtrl.push('DescriptionPage', clickedEpisode)
  }
}

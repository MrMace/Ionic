//created by Matt on 09/25/2017

var pageData = {};

function loadData() {
    $.getJSON("data/data.json", function(data){
        pageData = data;

        var newData = JSON.stringify(data);
        jQuery.post('data/data.json', {
            newData: newData

        })

    }).fail(function(error) {
        console.log("error", error);
    })
}




$(document).ready(function() {
    loadData();
});

(function ($) {
    $.fn.serializeFormJSON = function () {

        var a = this.serializeArray();
        $.each(a, function () {
            if (pageData[this.name]) {
                if (!pageData[this.name].push) {
                    pageData[this.name] = [pageData[this.name]];
                }
                pageData[this.name].push(this.value || '');
            } else {
                pageData[this.name] = this.value || '';
            }
        });
        return pageData;


    };
})(jQuery);

$('form').submit(function (e) {
    e.preventDefault();
    var data = $(this).serializeFormJSON();
    //Shows input data via console log.
    console.log(data);


});

//challenges
// post data to data.json
//post in correct order
// clear inputs on button click
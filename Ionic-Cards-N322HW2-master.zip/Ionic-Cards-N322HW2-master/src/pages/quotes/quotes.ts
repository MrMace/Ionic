import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the QuotesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */




@IonicPage()
@Component({
  selector: 'page-quotes',
  templateUrl: 'quotes.html',

})

export class QuotesPage {




  quotes = [
      {"imagePath": "Quote1.png",
      "title": "Funny Quote 1",
      "Description": "That moment you flex your foot wrong and it cramps. You think 'This is it. This is how it ends'",
      "faved": false
      ,"shared": false},

      {"imagePath": "Quote2.jpg",
      "title": "Funny Quote 2",
      "Description": "Have you ever listened to someone for a while and wondered.. 'Who ties your shoe laces for you?'"
          ,"faved": false
          ,"shared": false},

      {"imagePath": "Quote3.jpg",
      "title": "Funny Quote 3",
      "Description": "Walmart: The only place on earth you can get a Haircut, eye exam, ice cream sandwhich, tires for your car, and witness a real life 'What not to wear' episode."
          ,"faved": false
          ,"shared": false},

      {"imagePath": "Quote4.jpg",
      "title": "Motivational Quote 1",
      "Description": "You miss 100% of the shots you don't take."
          ,"faved": false
          ,"shared": false},

      {"imagePath": "Quote5.jpg",
      "title": "Motivational Quote 2",
      "Description": "Be a warrior not a worrier."
          ,"faved": false
          ,"shared": false},

      {"imagePath": "Quote6.jpg",
      "title": "Motivational Quote 3",
      "Description": "If you want to go big, stop thinking small."
          ,"faved": false
          ,"shared": false},

      {"imagePath": "Quote7.jpg",
      "title": "Motivational Quote 4",
      "Description": "Invest in your dreams. Grind now. Shine later"
          ,"faved": false
          ,"shared": false},

      {"imagePath": "Quote8.jpg",
      "title": "Motivational Quote 5",
      "Description": "Work hard in silence let your success be the noise."
          ,"faved": false
          ,"shared": false},

      {"imagePath": "Quote9.jpg",
      "title": "Motivational Quote 6",
      "Description": "Strength doesn't come from what you can do. It comes from overcoming the things you once thought you couldn't."
          ,"faved": false
          ,"shared": false},

      {"imagePath": "Quote10.jpg",
      "title": "Funny Quote 4",
      "Description": "I hate when I think I'm buying organic vegetables, and when I get home I discover they're just regular donuts."
          ,"faved": false
          ,"shared": false}


  ];

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad QuotesPage');
  }



    clickedFav(quote) {
        let index = this.quotes.indexOf(quote);
        if(index > -1) {
            if (quote.faved) {
                this.quotes[index].faved = false;
            } else {
                this.quotes[index].faved = true;
            }
        }
    }

    clickedShare(quote) {
        let index = this.quotes.indexOf(quote);
        if(index > -1) {
            if (quote.shared) {
                this.quotes[index].shared = false;
            } else {
                this.quotes[index].shared = true;
            }
        }
    }


    deleteItem(listedQuote){
        let index= this.quotes.indexOf(listedQuote);
        this.quotes.splice(index, 1);
    }



}
//
